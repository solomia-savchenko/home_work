import matplotlib.pyplot as plt
import numpy as np

def graph(y):
    x = 0.5 + np.arange(len(y))

    fig, ax = plt.subplots()
    ax.stem(x, y)

    plt.show()


