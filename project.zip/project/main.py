from charts.plots import graph

graph([1, 3, 5, 7, 4, 6, 4])


